import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { TabsPage } from './tabs.page';
import { InicioPage } from '../pages/inicio/inicio.page';
import { ListaNegociosPage } from '../pages/lista-negocios/lista-negocios.page';
import { MapaPage } from '../pages/mapa/mapa.page';
import { PerfilPage } from '../pages/perfil/perfil.page';

@NgModule({
  imports: [
    CommonModule,
    IonicModule,
    RouterModule.forChild([
      {
        path: '',
        component: TabsPage,
        children: [
          { path: 'inicio', component: InicioPage },
          { path: 'lista-negocios', component: ListaNegociosPage },
          { path: 'mapa', component: MapaPage },
          { path: 'perfil', component: PerfilPage },
          { path: '', redirectTo: 'inicio', pathMatch: 'full' }
        ]
      }
    ])
  ],
  declarations: []  // No declarar TabsPage porque es standalone
})
export class TabsPageModule {}  // ← Esto exporta la clase