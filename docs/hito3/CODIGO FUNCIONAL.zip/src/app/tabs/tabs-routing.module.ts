import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TabsPage } from './tabs.page';
import { InicioPage } from '../pages/inicio/inicio.page';
import { ListaNegociosPage } from '../pages/lista-negocios/lista-negocios.page';
import { MapaPage } from '../pages/mapa/mapa.page';
import { PerfilPage } from '../pages/perfil/perfil.page';

const routes: Routes = [
  {
    path: '',
    component: TabsPage,
    children: [
      {
        path: 'inicio',
        component: InicioPage
      },
      {
        path: 'lista-negocios',
        component: ListaNegociosPage
      },
      {
        path: 'mapa',
        component: MapaPage
      },
      {
        path: 'perfil',
        component: PerfilPage
      },
      {
        path: '',
        redirectTo: 'inicio',
        pathMatch: 'full'
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TabsPageRoutingModule {}