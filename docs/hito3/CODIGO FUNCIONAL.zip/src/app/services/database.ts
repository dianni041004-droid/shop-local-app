import { Injectable } from '@angular/core';

export interface Negocio {
  id: number;
  nombre: string;
  categoria: string;
  direccion: string;
  imagen: string;
  puntuacion: number;
  esFavorito: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class DatabaseService {

  private negocios: Negocio[] = [
    {
      id: 1,
      nombre: 'Colmado La Bendición',
      categoria: 'Comida',
      direccion: 'Calle Sol #10, Santiago',
      imagen: 'https://via.placeholder.com/150',
      puntuacion: 4.5,
      esFavorito: false
    },
    {
      id: 2,
      nombre: 'Tienda Estilo Local',
      categoria: 'Ropa',
      direccion: 'Av. Las Carreras, Santiago',
      imagen: 'https://via.placeholder.com/150',
      puntuacion: 4.8,
      esFavorito: false
    }
  ];

  constructor() { }

  getNegocios() {
    return this.negocios;
  }

  getFavoritos() {
    return this.negocios.filter(n => n.esFavorito);
  }

  toggleFavorito(id: number) {
    const negocio = this.negocios.find(n => n.id === id);
    if (negocio) {
      negocio.esFavorito = !negocio.esFavorito;
    }
  }
}
