import { Injectable } from '@angular/core';

export interface Negocio {
  id: number;
  nombre: string;
  categoria: string;
  lat: number;
  lng: number;
  direccion: string;
  telefono: string;
  rating: number;
  distancia: string;
  estado: string;
  descripcion: string;
}

@Injectable({
  providedIn: 'root'
})
export class NegociosService {
  private negocios: Negocio[] = [
    {
      id: 1,
      nombre: 'La Casita de Abuela',
      categoria: 'Restaurantes',
      lat: 19.4517,
      lng: -70.6970,
      direccion: 'Calle Principal #123, Santiago',
      telefono: '8095551234',
      rating: 4.5,
      distancia: '1.2 km',
      estado: 'Abierto',
      descripcion: 'Auténtica comida dominicana con los mejores sabores tradicionales.'
    },
    {
      id: 2,
      nombre: 'Plaza Comercial Central',
      categoria: 'Tiendas',
      lat: 19.4550,
      lng: -70.7000,
      direccion: 'Av. Central #45, Santiago',
      telefono: '8095555678',
      rating: 4.2,
      distancia: '2.5 km',
      estado: 'Abierto',
      descripcion: 'Variedad de tiendas en un solo lugar.'
    },
    {
      id: 3,
      nombre: 'Taller Express',
      categoria: 'Servicios',
      lat: 19.4480,
      lng: -70.6950,
      direccion: 'Calle Servicio #78, Santiago',
      telefono: '8095559012',
      rating: 4.0,
      distancia: '1.5 km',
      estado: 'Cerrado',
      descripcion: 'Reparación rápida de vehículos.'
    },
    {
      id: 4,
      nombre: 'Sushi Master',
      categoria: 'Restaurantes',
      lat: 19.4600,
      lng: -70.7020,
      direccion: 'Av. Japón #22, Santiago',
      telefono: '8095553456',
      rating: 4.8,
      distancia: '3.0 km',
      estado: 'Abierto',
      descripcion: 'El mejor sushi de la ciudad.'
    },
    {
      id: 5,
      nombre: 'Ferretería Don Juan',
      categoria: 'Tiendas',
      lat: 19.4530,
      lng: -70.6980,
      direccion: 'Calle Herrera #15, Santiago',
      telefono: '8095557890',
      rating: 4.3,
      distancia: '0.8 km',
      estado: 'Abierto',
      descripcion: 'Materiales de construcción y ferretería.'
    }
  ];

  getNegocios(): Negocio[] {
    return this.negocios;
  }

  getNegocioById(id: number): Negocio | undefined {
    return this.negocios.find(n => n.id === id);
  }

  getNegociosPorCategoria(categoria: string): Negocio[] {
    return this.negocios.filter(n => n.categoria === categoria);
  }

  buscarNegocios(termino: string): Negocio[] {
    if (!termino) return this.negocios;
    const busqueda = termino.toLowerCase();
    return this.negocios.filter(n => 
      n.nombre.toLowerCase().includes(busqueda) || 
      n.categoria.toLowerCase().includes(busqueda)
    );
  }
}