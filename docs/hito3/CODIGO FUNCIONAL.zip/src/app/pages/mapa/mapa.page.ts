import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { IonHeader, IonToolbar, IonTitle, IonContent, IonFab, IonFabButton, IonIcon } from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { locateOutline, businessOutline, navigateOutline } from 'ionicons/icons';
import { NegociosService } from '../../services/negocios';
import * as L from 'leaflet';

@Component({
  selector: 'app-mapa',
  templateUrl: './mapa.page.html',
  styleUrls: ['./mapa.page.scss'],
  standalone: true,
  imports: [IonHeader, IonToolbar, IonTitle, IonContent, IonFab, IonFabButton, IonIcon]
})
export class MapaPage implements OnInit, AfterViewInit {
  map!: L.Map;
  private mapaInicializado: boolean = false;

  constructor(
    private router: Router, 
    private route: ActivatedRoute,
    private negociosSvc: NegociosService
  ) {
    addIcons({ locateOutline, businessOutline, navigateOutline });
  }

  ngOnInit() {
    // Escuchar parámetros de navegación
    this.route.queryParams.subscribe(params => {
      if (params['lat'] && params['lng'] && this.mapaInicializado) {
        setTimeout(() => {
          this.enfocarNegocio(params['lat'], params['lng'], params['nombre']);
        }, 500);
      }
    });
  }

  ngAfterViewInit() {
    // Esperar a que el DOM esté listo
    setTimeout(() => {
      this.initMap();
    }, 500);
  }

  initMap() {
    // Verificar si el contenedor existe
    const mapContainer = document.getElementById('mapId');
    if (!mapContainer) {
      console.error('No se encontró el contenedor del mapa');
      return;
    }

    // Configurar iconos por defecto de Leaflet
    const defaultIcon = L.icon({
      iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
      shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
      iconSize: [25, 41],
      iconAnchor: [12, 41],
      popupAnchor: [1, -34]
    });
    L.Marker.prototype.options.icon = defaultIcon;

    try {
      // Santiago de los Caballeros como centro por defecto
      this.map = L.map('mapId').setView([19.4517, -70.6970], 14);

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
        maxZoom: 19
      }).addTo(this.map);

      // Forzar actualización del tamaño del mapa
      setTimeout(() => {
        this.map.invalidateSize();
      }, 200);

      this.mapaInicializado = true;
      this.cargarComercios();
      
    } catch (error) {
      console.error('Error al inicializar el mapa:', error);
    }
  }

  cargarComercios() {
    if (!this.map) return;
    
    const comercios = this.negociosSvc.getNegocios();

    comercios.forEach(c => {
      const marker = L.marker([c.lat, c.lng]).addTo(this.map);

      const popupHTML = `
        <div style="width: 200px; text-align: center; padding: 8px;">
          <b style="font-size: 14px; display: block; margin-bottom: 5px;">${c.nombre}</b>
          <span style="color: #666; font-size: 11px; display: block; margin-bottom: 10px;">${c.categoria} • ${c.distancia}</span>
          <button id="btn-det-${c.id}" style="background: #3880ff; color: white; border: none; width: 100%; padding: 8px; border-radius: 8px; font-weight: bold; margin-bottom: 5px; cursor: pointer;">
            📋 VER DETALLE
          </button>
          <button id="btn-nav-${c.id}" style="background: #2dd36f; color: white; border: none; width: 100%; padding: 8px; border-radius: 8px; font-weight: bold; cursor: pointer;">
            🗺️ CÓMO LLEGAR
          </button>
        </div>
      `;

      marker.bindPopup(popupHTML);

      marker.on('popupopen', () => {
        // Botón Ver Detalle
        const detalleBtn = document.getElementById(`btn-det-${c.id}`);
        if (detalleBtn) {
          detalleBtn.addEventListener('click', () => {
            this.router.navigate(['/detalle-negocio'], { queryParams: { id: c.id } });
          });
        }

        // Botón Cómo Llegar
        const navegarBtn = document.getElementById(`btn-nav-${c.id}`);
        if (navegarBtn) {
          navegarBtn.addEventListener('click', () => {
            window.open(`https://www.google.com/maps/dir/?api=1&destination=${c.lat},${c.lng}`, '_system');
          });
        }
      });
    });
  }

  enfocarNegocio(lat: any, lng: any, nombre: string) {
    if (!this.map) return;
    
    const coords: L.LatLngExpression = [parseFloat(lat), parseFloat(lng)];
    this.map.flyTo(coords, 16, { animate: true, duration: 1.5 });
    
    L.marker(coords).addTo(this.map)
      .bindPopup(`<b>${nombre}</b><br>📍 Ubicación exacta`)
      .openPopup();
  }

  centrarMiUbicacion() {
    console.log('Centrando en ubicación actual...');
    
    if (!this.map) {
      console.error('El mapa no está inicializado');
      return;
    }

    // Verificar si el navegador soporta geolocalización
    if (!navigator.geolocation) {
      console.warn('Geolocalización no soportada');
      // Centrar en Santiago por defecto
      this.map.flyTo([19.4517, -70.6970], 14);
      return;
    }

    // Obtener ubicación actual
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        const coords: L.LatLngExpression = [lat, lng];
        
        console.log('Ubicación obtenida:', lat, lng);
        this.map.flyTo(coords, 16, { animate: true, duration: 1 });
        
        // Agregar marcador de ubicación actual
        L.marker(coords, {
          icon: L.divIcon({
            className: 'current-location-marker',
            html: '<div style="background: #2dd36f; width: 20px; height: 20px; border-radius: 50%; border: 3px solid white; box-shadow: 0 0 5px rgba(0,0,0,0.5);"></div>',
            iconSize: [20, 20]
          })
        }).addTo(this.map).bindPopup('<b>📍 Tu ubicación actual</b>').openPopup();
      },
      (error) => {
        console.error('Error de geolocalización:', error.message);
        // Fallback: centrar en Santiago
        this.map.flyTo([19.4517, -70.6970], 14);
        
        // Mostrar mensaje al usuario
        alert('No se pudo obtener tu ubicación. Asegúrate de permitir el acceso a la ubicación.');
      },
      { 
        enableHighAccuracy: true, 
        timeout: 10000, 
        maximumAge: 0 
      }
    );
  }
}