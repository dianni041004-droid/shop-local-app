import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NegociosService, Negocio } from '../../services/negocios';
import { CommonModule } from '@angular/common';
import { 
  IonContent, 
  IonHeader, 
  IonToolbar, 
  IonTitle, 
  IonButtons, 
  IonBackButton, 
  IonList, 
  IonItem, 
  IonLabel, 
  IonIcon, 
  IonChip 
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { star, businessOutline } from 'ionicons/icons';

@Component({
  selector: 'app-lista-negocios',
  templateUrl: './lista-negocios.page.html',
  styleUrls: ['./lista-negocios.page.scss'],
  standalone: true,
  imports: [
    CommonModule, 
    IonContent, 
    IonHeader, 
    IonToolbar, 
    IonTitle, 
    IonButtons, 
    IonBackButton, 
    IonList, 
    IonItem, 
    IonLabel, 
    IonIcon, 
    IonChip
  ]
})
export class ListaNegociosPage implements OnInit {
  negociosFiltrados: Negocio[] = [];

  constructor(
    private route: ActivatedRoute,
    private negociosSvc: NegociosService,
    private router: Router
  ) {
    addIcons({ star, businessOutline });
    console.log('📋 ListaNegociosPage inicializada');
  }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      const cat = params['cat'];
      const search = params['search'];
      
      console.log('📋 Parámetros recibidos:', { cat, search });
      
      let negocios = this.negociosSvc.getNegocios();
      
      if (cat && cat !== '') {
        negocios = this.negociosSvc.getNegociosPorCategoria(cat);
        console.log(`📋 Filtrado por categoría ${cat}:`, negocios.length);
      }
      
      if (search && search !== '') {
        negocios = this.negociosSvc.buscarNegocios(search);
        console.log(`📋 Filtrado por búsqueda "${search}":`, negocios.length);
      }
      
      this.negociosFiltrados = negocios;
      console.log('📋 Negocios filtrados finales:', this.negociosFiltrados.length);
    });
  }

  verDetalle(n: Negocio) {
    console.log('🔍 Ver detalle de negocio:', n.id, n.nombre);
    this.router.navigate(['/detalle-negocio'], { queryParams: { id: n.id } });
  }
}