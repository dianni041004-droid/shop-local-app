import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ListaNegociosPage } from './lista-negocios.page';

describe('ListaNegociosPage', () => {
  let component: ListaNegociosPage;
  let fixture: ComponentFixture<ListaNegociosPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ListaNegociosPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
