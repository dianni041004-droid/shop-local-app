import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { 
  IonContent, 
  IonSearchbar, 
  IonButton, 
  IonIcon 
} from '@ionic/angular/standalone';

import { addIcons } from 'ionicons';
import { 
  restaurantOutline, 
  cartOutline, 
  constructOutline, 
  mapOutline, 
  searchOutline 
} from 'ionicons/icons';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.page.html',
  styleUrls: ['./inicio.page.scss'],
  standalone: true,
  imports: [
    CommonModule, 
    FormsModule, 
    IonContent, 
    IonSearchbar, 
    IonButton, 
    IonIcon
  ]
})
export class InicioPage implements OnInit {
  searchTerm: string = '';

  constructor(private router: Router) {
    addIcons({ 
      restaurantOutline, 
      cartOutline, 
      constructOutline, 
      mapOutline, 
      searchOutline 
    });
    console.log('✅ InicioPage inicializada');
  }

  ngOnInit() {}

  onSearch(event: any) {
    this.searchTerm = event.detail.value;
    console.log('🔍 Búsqueda:', this.searchTerm);
  }

  testClick() {
    console.log('🎯 ¡CLICK FUNCIONA!');
    alert('✅ El botón funciona correctamente');
  }

  irARestaurantes() {
    console.log('🍔 Click en Restaurantes');
    this.router.navigate(['/tabs/lista-negocios'], { 
      queryParams: { cat: 'Restaurantes', search: this.searchTerm } 
    });
  }

  irATiendas() {
    console.log('🛍️ Click en Tiendas');
    this.router.navigate(['/tabs/lista-negocios'], { 
      queryParams: { cat: 'Tiendas', search: this.searchTerm } 
    });
  }

  irAServicios() {
    console.log('🔧 Click en Servicios');
    this.router.navigate(['/tabs/lista-negocios'], { 
      queryParams: { cat: 'Servicios', search: this.searchTerm } 
    });
  }

  irAlMapa() {
    console.log('🗺️ Click en Mapa');
    this.router.navigate(['/tabs/mapa']);
  }
}