import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NegociosService, Negocio } from '../../services/negocios';
import { CommonModule } from '@angular/common';
import { 
  IonContent, 
  IonHeader, 
  IonToolbar, 
  IonTitle, 
  IonButtons, 
  IonBackButton, 
  IonButton, 
  IonIcon, 
  IonCard, 
  IonCardContent 
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { callOutline, mapOutline, star, timeOutline, locationOutline, businessOutline } from 'ionicons/icons';

@Component({
  selector: 'app-detalle-negocio',
  templateUrl: './detalle-negocio.page.html',
  styleUrls: ['./detalle-negocio.page.scss'],
  standalone: true,
  imports: [
    CommonModule, 
    IonContent, 
    IonHeader, 
    IonToolbar, 
    IonTitle, 
    IonButtons, 
    IonBackButton, 
    IonButton, 
    IonIcon, 
    IonCard, 
    IonCardContent
  ]  // ← Eliminado IonText
})
export class DetalleNegocioPage implements OnInit {
  negocio?: Negocio;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private negociosSvc: NegociosService
  ) {
    addIcons({ 
      callOutline, 
      mapOutline, 
      star, 
      timeOutline, 
      locationOutline, 
      businessOutline 
    });
  }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      const id = params['id'];
      if (id) {
        this.negocio = this.negociosSvc.getNegocioById(Number(id));
        console.log('Negocio cargado:', this.negocio);
      }
    });
  }

  llamar() {
    if (this.negocio) {
      window.open(`tel:${this.negocio.telefono}`, '_system');
    }
  }

  verEnMapa() {
    if (this.negocio) {
      this.router.navigate(['/tabs/mapa'], { 
        queryParams: { 
          lat: this.negocio.lat, 
          lng: this.negocio.lng,
          nombre: this.negocio.nombre 
        } 
      });
    }
  }
}