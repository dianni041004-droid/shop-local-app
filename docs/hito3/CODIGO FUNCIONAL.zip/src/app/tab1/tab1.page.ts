import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular'; 
import { CommonModule } from '@angular/common'; 
import { FormsModule } from '@angular/forms'; 

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule] 
})
export class Tab1Page {

  negocios = [
    {
      nombre: 'Colmado La Esperanza',
      categoria: 'Víveres',
      imagen: 'https://via.placeholder.com/150',
      descripcion: 'El mejor servicio del barrio.'
    },
    {
      nombre: 'Pizzería Don Juan',
      categoria: 'Comida',
      imagen: 'https://via.placeholder.com/150',
      descripcion: 'Pizzas a la leña artesanales.'
    },
    {
      nombre: 'Ferretería El Clavo',
      categoria: 'Construcción',
      imagen: 'https://via.placeholder.com/150',
      descripcion: 'Todo para tu hogar.'
    }
  ];

  constructor() {}

}